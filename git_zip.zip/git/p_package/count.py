def addition(*numbers):
    return sum(numbers)
def subtract(*numbers):
    if not numbers:
        return 0
    result = numbers[0]
    for num in numbers[1:]:
        result -= num
    return result

def multiply(*numbers):
    if not numbers:
        return 0
    result = 1
    for num in numbers:
        result *= num
    return result

def divide(*numbers):
    if not numbers:
        return "Error: No numbers given"
    result = numbers[0]
    for num in numbers[1:]:
        if num == 0:
            return "Error: Division by zero"
        result /= num
    return result

def modulus(*numbers):
    if not numbers:
        return "Error: No numbers given"
    result = numbers[0]
    for num in numbers[1:]:
        if num == 0:
            return "Error: Modulus by zero"
        result %= num
    return result
def percentage(value, total):
    if total == 0:
        return "Error: Total cannot be zero"
    percent = (value / total) * 100
    return percent
